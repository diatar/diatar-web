package eu.diatar.library;

public class RecPic extends RecPicBase
{
	public static final int bgCENTER = 0;
	public static final int bgZOOM = 1;
	public static final int bgFULL = 2;
	public static final int bgCASCADE = 3;
	public static final int bgMIRROR = 4;
	
	public RecPic(int recsize) { super(recsize); }
}
