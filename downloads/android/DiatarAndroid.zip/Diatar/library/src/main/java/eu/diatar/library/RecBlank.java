package eu.diatar.library;

public class RecBlank extends RecPicBase
{
	public RecBlank(int recsize) { super(recsize); }
}
