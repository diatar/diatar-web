# diatar-android
A [diatar.eu](https://diatar.eu) templomi kivetítő rendszer androidos alkalmazásainak forráskódja.

Az alkalmazás letölthető a Google Playről:
[Diatár](https://play.google.com/store/apps/details?id=diatar.eu) és [DiaVetítő](https://play.google.com/store/apps/details?id=com.polyjoe.DiaVetito)

Leírás az androidos vetítés lehetőségeiről: https://diatar.eu/Android/androidkutyu.html

A kommunikáció leírása vetítő és vezérlő között, ami minden platromra érvényes: [diatar-lazarus/kommunikacio.md](https://github.com/diatar/diatar-lazarus/blob/main/kommunikacio.md)
