DIATAR
  projektoros templomi �nekvet�t�st seg�t� program
  worship software

Ez a program a templomi �neksz�vegek projektoros vet�t�s�re szolg�l.
Seg�ti a k�ntort az �nek-rendek �ssze�ll�t�s�ban �s kezel�s�ben. K�pek vet�t�s�t is lehet�v� teszi.

This hungarian program utilizes projectors to show lyrics during church ceremonies.
It helps cantors to collect, form and manage the list of songs, including pictures also.

Author: Jozsef Rieth
Language: Hungarian
web: http://www.diatar.eu
email: hoze@diatar.eu or hoze@tvnetwork.hu
licence: GNU-GPL (see copyright file)

Programing language: Lazarus 1.6.2 (FPC 3.0.0)
External packages: lNet (http://wiki.lazarus.freepascal.org/lNet)


Csak ki kell t�m�r�teni a ZIP f�jlt egy k�nyvt�rba �s m�ris haszn�lhat�, a DIATAR.EXE illetve DIAEDITOR.EXE a futtatand� program. A haszn�lathoz a .DTX f�jloknak a programmal azonos k�nyvt�rban kell lenni!
Ha printer-portos t�vkapcsol�-illeszt�re van sz�ks�g, els� alkalommal �r�si jog kell a C:\WINDOWS\SYSTEM32 k�nyvt�rhoz, ahova egy service rutint telep�t (ld. a haszn�lati �tmutat�ban).

Just unzip to an empty folder (typically: C:\DIATAR) and it is ready to use; run DIATAR.EXE or DIAEDITOR.EXE files. To use, copy the .DTX files (song-text volumes) into the same folder.
For the remote control through printer-port one time give the program write permission to the folder C:\WINDOWS\SYSTEM32, it will install a small service routine (namely HWINTERFACE.SYS - which does nothing else than physically reads/writes the port - see the source code in HwIO.pas)
