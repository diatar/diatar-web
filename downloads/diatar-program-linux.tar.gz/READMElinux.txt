DIATAR
  projektoros templomi �nekvet�t�st seg�t� program
  worship software

Ez a program a templomi �neksz�vegek projektoros vet�t�s�re szolg�l.
Seg�ti a k�ntort az �nek-rendek �ssze�ll�t�s�ban �s kezel�s�ben. K�pek vet�t�s�t is lehet�v� teszi.

This hungarian program utilizes projectors to show lyrics during church ceremonies.
It helps cantors to collect, form and manage the list of songs, including pictures also.

Author: Jozsef Rieth
Language: Hungarian
web: http://www.diatar.eu
email: hoze@diatar.eu or hoze@tvnetwork.hu
licence: GNU-GPL (see copyright file)

Programing language: Lazarus 1.6.2 (FPC 3.0.0)
External packages: lNet (http://wiki.lazarus.freepascal.org/lNet)


Csak ki kell t�m�r�teni a tar.gz f�jlt egy k�nyvt�rba �s m�ris haszn�lhat�, a diatar illetve diaeditor (64bites rendszeren: diatar64 �s diaeditor64) a futtatand� program. A haszn�lathoz a .DTX f�jloknak a programmal azonos k�nyvt�rban kell lenni!
Ha printer-portos t�vkapcsol�-illeszt�re van sz�ks�g, az ioroutine (ioroutine64) bin�risra is sz�ks�g van, setuid root joggal (ld. a haszn�lati �tmutat�ban).
A legjobb telep�t�si m�dszer jelenleg a .deb csomag haszn�lata!

Just unpack to an empty folder and it is ready to use; run diatar or diaeditor files (on 64bit system diatar64 or diaeditor64). To use, copy the .DTX files (song-text volumes) into the same folder.
For the remote control through printer-port copy the ioroutine (ioroutine64) into the same folder and give it setuid root permissions (this binary does nothing else than physically reads/writes the port - see the source code).
Also the best choice is to install the software from the .deb package!

