#!/bin/sh
export PATH=$PATH:/opt/diatar/bin
