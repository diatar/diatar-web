Template: diatar/download_mp3
Type: boolean
Default: false
Description: Do you want to download all .mp3 files?
Description-hu: Le akarod tölteni az összes mp3 hang filet?
