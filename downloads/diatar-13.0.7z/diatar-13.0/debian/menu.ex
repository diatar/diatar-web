?package(diatar):needs="X11" section="Applications/Viewers"\
  title="Diataar" command="$HOME/diatar icon="$HOME/.icons/diatar.png"
