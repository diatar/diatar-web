#
# Regular cron jobs for the diatar package
#
0 4	* * *	root	[ -x /usr/bin/diatar_maintenance ] && /usr/bin/diatar_maintenance
